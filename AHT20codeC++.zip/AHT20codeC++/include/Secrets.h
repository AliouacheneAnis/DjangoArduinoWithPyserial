/*
SSID du WIFI ainsi que le mot de passe
Modifier les paramètre WIFI pour le réseau auquels votre objets doit se brancher
*/

#define WIFI_SECRET_SSID "IDO-OBJECTS"
#define WIFI_SECRET_PASS "42Bidules!"

/*
Information nécessaire pour le branchement a un Broker MQTT
Dans le cadre du cours AIIA1013, ne modifié pas cet information
*/

#define SECRET_MQTT_SERVER_IP "198.164.130.74"
#define SECRET_MQTT_SERVER_PORT 1883

/*
Détails sur l'indentification de l'objet
Cette information provient de l'objet virtuel créer sur le serveur Thingsbord
*/

#define SECRET_TOKEN  "N1cM51fWjK5ihjM05cfU"
#define SECRET_DEVICE_ID "c4c599a0-a525-11ec-9235-d318ce92df6e"



